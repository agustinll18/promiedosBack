/* const likeSchema = new mongoose.Schema({
  username: String,
  date: { type: Date, default: Date.now },
  // Puedes agregar más campos según sea necesario
});

const postSchema = new mongoose.Schema({
  content: String,
  username: String,
  date: { type: Date, default: Date.now },
  likes: [likeSchema],
  // Otros campos según sea necesario
});

const Post = mongoose.model("Post", postSchema);

module.exports = Post;
 */